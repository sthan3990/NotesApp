<<<<<<< HEAD
// Client facing scripts here


=======
// Client facing scripts here
>>>>>>> 578b71b (Implemented database.js Adding queries for login, register, Also fixed)
