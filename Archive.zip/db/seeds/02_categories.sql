INSERT INTO Categories (category_name) VALUES
('Film / Series (To watch)'),
('Restaurants, cafes, etc. (To eat)'),
('Books (To read)'),
('Products (To buy)');
