INSERT INTO Items (item_name, category_id, user_id, status) VALUES 
('The Godfather', 1, 1, 'To watch'),
('The Coffee Shop', 2, 1, 'To eat'),
('1984', 3, 1, 'To read'),
('New Laptop', 4, 1, 'To buy');